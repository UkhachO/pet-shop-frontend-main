const categories = [
  { id: 1, name: "Dry & Wet Food", image: "/assets/cat1.jpg" },
  { id: 2, name: "Toys", image: "/assets/cat2.jpg" },
  { id: 3, name: "Beds", image: "/assets/cat3.jpg" },
  { id: 4, name: "Accessories", image: "/assets/cat4.jpg" },
  { id: 5, name: "Grooming", image: "/assets/cat5.jpg" },
  { id: 6, name: "Collars & Leashes", image: "/assets/cat6.jpg" },
];

export default categories;
