const contacts = {
  phone: "+49 30 915-88492",
  address: "Wallstraẞe 9-13, 10179 Berlin, Deutschland",
  hours: "24 hours a day",
  socials: {
    instagram: "https://instagram.com",
    whatsapp: "https://whatsapp.com",
  },
};

export default contacts;
