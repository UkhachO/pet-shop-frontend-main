const products = [
  {
    id: 1,
    name: "Dog Food",
    price: 12.99,
    image: "/assets/prod1.jpg",
    description: "High-quality dry and wet dog food for all breeds.",
  },
  {
    id: 2,
    name: "Cat Toy",
    price: 5.49,
    image: "/assets/prod2.jpg",
    description: "High-quality dry and wet dog food for all breeds.",
  },
  {
    id: 3,
    name: "Pet Bed",
    price: 29.99,
    image: "/assets/prod3.jpg",
    description: "High-quality dry and wet dog food for all breeds.",
  },
  {
    id: 4,
    name: "Leash",
    price: 9.99,
    image: "/assets/prod4.jpg",
    description: "High-quality dry and wet dog food for all breeds.",
  },
];

export default products;
