import { configureStore } from "@reduxjs/toolkit";
import cartReducer from "./cart/cart-slice";
import categoriesReducer from "./categories/categoriesSlice";
import productsReducer from "./products/productsSlice";
import saleReducer from "./sale/saleSlice";

export default configureStore({
  reducer: {
    cart: cartReducer,
    categories: categoriesReducer,
    products: productsReducer,
    sale: saleReducer,
  },
});
